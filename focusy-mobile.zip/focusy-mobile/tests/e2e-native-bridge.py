# Run: python3 e2e-native-bridge.py   (needs playwright + chromium). Tests the web app + native.js against a FAKE Capacitor.
# This verifies the bridge logic only. It does not prove behaviour on a real Android/iOS device.
import datetime,json,os,sys
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__));URL='file://'+os.path.join(HERE,'..','web','index.html')
d=lambda n:(datetime.date.today()+datetime.timedelta(days=n)).isoformat()
R=[];ck=lambda c,m:R.append(('PASS' if c else 'FAIL')+': '+m)
def T(i,t,due,est=0):
    return {"id":i,"title":t,"notes":"","status":"todo","important":True,"urgent":None,"dueDate":due,"scheduledDate":"","createdAt":"","updatedAt":"","completedAt":None,"deletedAt":None,"plan":{"estMin":est,"doneMin":0,"target":"","days":[1,2,3,4,5,6,0],"start":"18:00","sessionMin":60,"mode":"auto","stale":True} if est else None}
S={"tasks":[T("a","Creative writing",d(6),600)],"blocks":[],"prio":{},"set":{"theme":"dark","weekStart":1,"jny":{"on":True}},"sess":None}
FAKE="""
(()=>{const calls=window.__calls=[];const rec=(n,a)=>calls.push([n,a]);window.__perm='prompt';window.__listeners={};
const P={
 LocalNotifications:{checkPermissions:async()=>({display:window.__perm}),requestPermissions:async()=>{rec('requestPermissions');window.__perm='granted';return{display:'granted'}},
  createChannel:async a=>rec('createChannel',a),cancel:async a=>rec('cancel',a),schedule:async a=>rec('schedule',{notifications:a.notifications.map(n=>({...n,schedule:{...n.schedule,at:n.schedule.at.getTime()}}))}),removeAllDeliveredNotifications:async()=>rec('removeDelivered'),addListener:async(e,f)=>{window.__listeners[e]=f}},
 Preferences:{get:async a=>({value:await window.pref_get(a.key)}),set:async a=>{await window.pref_set(a.key,a.value);rec('prefSet',a.key)}},
 KeepAwake:{keepAwake:async()=>rec('keepAwake'),allowSleep:async()=>rec('allowSleep')},
 StatusBar:{setStyle:async a=>rec('sbStyle',a),setBackgroundColor:async a=>rec('sbColor',a)},
 SplashScreen:{hide:async()=>rec('splashHide')},Keyboard:{addListener:async(e,f)=>{window.__listeners[e]=f}},
 App:{addListener:async(e,f)=>{window.__listeners[e]=f},minimizeApp:async()=>rec('minimizeApp')}};
window.Capacitor={isNativePlatform:()=>true,getPlatform:()=>'android',Plugins:P};})();
"""
store={}
def mk(b,native=True,**kw):
    ctx=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,**kw);pg=ctx.new_page();pg.errs=[];pg.on("pageerror",lambda e:pg.errs.append(str(e)))
    if native:
        pg.expose_function('pref_get',lambda k:store.get(k));pg.expose_function('pref_set',lambda k,v:store.__setitem__(k,v));pg.add_init_script(FAKE)
    return ctx,pg
calls=lambda pg,n:[c for c in pg.evaluate("window.__calls") if c[0]==n]
def start(pg):
    pg.click('[data-nav="deadlines"]');pg.click('.rt[data-open] >> nth=0');pg.click('[data-act="focusnow"]');pg.wait_for_timeout(500)
with sync_playwright() as p:
    b=p.chromium.launch()
    # ---- plain browser: bridge is inert
    ctx,pg=mk(b,native=False);pg.goto(URL);pg.evaluate("s=>localStorage.setItem('uf1',s)",json.dumps(S));pg.reload();start(pg)
    ck(pg.evaluate("FocusyNative.native===false")and pg.is_visible('#jcv'),'web: bridge inactive, journey still starts');pg.click('[data-act="tstop"]');ck(pg.errs==[],'web: no JS errors '+str(pg.errs));ctx.close()
    # ---- native (fake)
    ctx,pg=mk(b);pg.goto(URL);pg.evaluate("s=>localStorage.setItem('uf1',s)",json.dumps(S));pg.reload();pg.wait_for_timeout(300)
    ck(pg.evaluate("FocusyNative.native&&FocusyNative.platform==='android'"),'native detected')
    ck(len(calls(pg,'createChannel'))==1 and len(calls(pg,'splashHide'))==1,'notification channel created; splash hidden')
    ck(any(c[1].get('style')=='DARK' for c in calls(pg,'sbStyle')),'status bar set light-on-dark for dark theme')
    start(pg);pg.wait_for_timeout(600)
    ck(len(calls(pg,'requestPermissions'))==1,'notification permission requested once, when the first session starts')
    sc=calls(pg,'schedule');ck(len(sc)==1,'alerts scheduled on Start Focus ('+str(len(sc))+' calls)')
    ns=sc[-1][1]['notifications'];ids=sorted(n['id'] for n in ns);planned=pg.evaluate("S.sess.plannedMs");now=pg.evaluate("Date.now()")
    ck(9001 in ids,'session-end alert present ids='+str(ids));end=[n for n in ns if n['id']==9001][0]
    ck(abs(end['schedule']['at']-(now+planned))<4000,'end alert lands at planned end (within 4s)')
    ck(all(n['schedule']['allowWhileIdle'] and n['channelId']=='focus' for n in ns),'alerts use the focus channel and allowWhileIdle')
    ck(len(calls(pg,'keepAwake'))>=1,'screen kept awake while running')
    # pause -> alerts cancelled, no new schedule
    n0=len(calls(pg,'schedule'));c0=len(calls(pg,'cancel'));pg.click('[data-act="tpause"]');pg.wait_for_timeout(500)
    ck(len(calls(pg,'cancel'))>c0 and len(calls(pg,'schedule'))==n0,'pause cancels alerts, schedules none')
    ck(len(calls(pg,'allowSleep'))>=1,'screen may sleep while paused')
    pg.click('[data-act="tpause"]');pg.wait_for_timeout(500);ck(len(calls(pg,'schedule'))==n0+1,'resume schedules again')
    # adjust duration -> reschedule at new end
    pg.click('[data-act="tadjust"]');pg.click('[data-act="tdur"][data-v="45"]');pg.wait_for_timeout(500);ck(len(calls(pg,'schedule'))==n0+2,'changing duration reschedules')
    # storage mirror
    pg.wait_for_timeout(700);ck('uf1' in store and json.loads(store['uf1'])['sess'] is not None,'state mirrored to Preferences (includes running session)')
    # Android back button minimizes the timer, then minimizes the app
    pg.evaluate("window.__listeners.backButton()");pg.wait_for_timeout(250);ck(not pg.is_visible('#timer') and pg.is_visible('#pill'),'back button minimizes the timer')
    pg.evaluate("window.__listeners.backButton()");pg.wait_for_timeout(150);ck(len(calls(pg,'minimizeApp'))==1,'back button on home minimizes the app')
    # alert fires while app is open -> duplicate removed
    pg.evaluate("window.__listeners.localNotificationReceived()");pg.wait_for_timeout(100);ck(len(calls(pg,'removeDelivered'))==1,'foreground duplicate alert is cleared')
    # app resume re-runs the app resume logic (locked 10 min)
    pg.evaluate("S.sess.resumedAt-=10*60000;save()");pg.evaluate("window.__listeners.appStateChange({isActive:true})");pg.wait_for_timeout(300);ck(True,'resume event handled without error')
    # stop -> everything cancelled
    pg.click('#pill button');pg.click('[data-act="tstop"]');pg.wait_for_timeout(500);ck(calls(pg,'cancel')[-1][1]['notifications'][0]['id']==9001,'stop cancels alerts')
    # More: notifications button reflects permission
    pg.click('[data-nav="more"]');ck('Notifications on' in pg.inner_text('#main'),'Settings shows notifications enabled')
    ck(pg.errs==[],'native: no JS errors '+str(pg.errs))
    # data safety: WebView storage wiped, Preferences copy restores it
    pg.evaluate("localStorage.removeItem('uf1')");pg.reload();pg.wait_for_function("typeof S!==\"undefined\"&&S.tasks&&S.tasks.length===1",timeout=6000)
    ck(pg.evaluate("S.tasks.length")==1 and pg.evaluate("S.tasks[0].title")=='Creative writing','storage wiped -> tasks restored from Preferences')
    ck(pg.errs==[],'after restore: no JS errors');ctx.close()
    # brand-new WebView with empty storage but an existing backup: the backup must survive the app's blank first save
    ctx,pg=mk(b)
    pg.goto(URL);pg.wait_for_function("typeof S!==\"undefined\"",timeout=5000);pg.wait_for_timeout(1500)
    ck(json.loads(store['uf1'])['tasks'] and len(json.loads(store['uf1'])['tasks'])==1,'empty WebView + existing backup: backup survives and is restored');ctx.close()
    store.clear()
    # permission denied -> no scheduling, app keeps working
    ctx,pg=mk(b);pg.add_init_script("window.__perm='denied'");pg.goto(URL);pg.evaluate("s=>localStorage.setItem('uf1',s)",json.dumps(S));pg.reload();start(pg);pg.wait_for_timeout(500)
    ck(len(calls(pg,'schedule'))==0 and pg.is_visible('#jcv'),'permission denied: no alerts, journey/timer still run');ck(pg.errs==[],'denied: no JS errors');ctx.close()
    b.close()
print('\n'.join(R));f=sum(r.startswith('FAIL') for r in R);print(sum(r.startswith('PASS') for r in R),'passed',f,'failed');sys.exit(1 if f else 0)
