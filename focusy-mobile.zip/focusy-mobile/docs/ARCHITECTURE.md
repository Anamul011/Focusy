# Architecture decision

## What the codebase is
A single HTML file (~110 KB): vanilla JS, canvas Journey, state in `localStorage` key `uf1`, a pure unit-testable engine (planner, movement, journey), Web Audio sounds, no external requests, no build step, no framework. Sync exists only through the artifact host's `claude.use('db')` and `claude.use('user')` APIs.

## Options considered
| Option | Reuse | Effort | Risks |
|---|---|---|---|
| **Capacitor (chosen)** | ~100% of UI, logic, Journey, tests | Low | WebView performance is device-dependent; native feel comes from our CSS, not native widgets |
| React Native / Flutter | ~0%: full rewrite of timer, planner, Journey canvas | Very high | Regressions in logic that is already tested; two codebases to keep equal with web |
| PWA / Android TWA | 100% | Lowest | No reliable background alerts on iOS, weaker App Store case, no Preferences safety copy |
| Fully native (Kotlin + Swift) | 0% | Highest | Three codebases |

**Decision: Capacitor.** The app is already offline-first, touch-first and self-contained. Capacitor gives real store packages while keeping one codebase. If device testing shows the Journey cannot hold 30+ fps on mid-range Android, the fallback is to lower the canvas resolution (one constant) before considering any rewrite.

## The hard problems and how they are handled
| Problem | Why it matters | Solution |
|---|---|---|
| Timers freeze in the background | A phone suspends JS | Time is never counted by ticks. Progress is derived from timestamps (`sessMs`), so any resume is exact. Already true on web |
| Alerts while backgrounded or locked | Session end, movement, break end must still fire | `notePlan()` (pure, unit tested) lists the alerts for the current session; `native.js` schedules them with the OS (LocalNotifications) on every save and cancels them on pause/stop/adjust. At most 3 pending alerts |
| iOS has no Web Notification API | The old "Enable notifications" path would not work | Button now asks the OS through the plugin when running natively |
| WebView storage can be cleared by the OS | Possible task loss | `uf1` is mirrored to Preferences (UserDefaults / SharedPreferences) 400 ms after each save and on backgrounding. On launch with empty storage the backup is restored. Mirroring is paused during the restore check so a blank first save can never overwrite the backup |
| Screen sleeping during focus | Journey and timer need the screen | KeepAwake only while a session is running |
| Notches, status bar, keyboard | Premium feel | `viewport-fit=cover`, top safe-area padding, status bar styled per theme, keyboard resize + scroll focused field into view |
| Android back button | Would exit the app mid-session | Minimizes the timer, then closes a sheet, then minimizes the app |
| Completion sound | Web Audio only plays in the foreground | Foreground: existing chime. Background: the system notification sound (custom chime file is a follow-up) |

## What the app does NOT do natively (by design)
No analytics, no network calls, no accounts, no push server. Data stays on the device.

## Sync and accounts (not implemented in native builds)
Cross-device sync today works only inside the artifact host. A store app needs its own backend. Required, if you want it:
1. Authentication (email link + Sign in with Apple; Apple requires Sign in with Apple if other social logins are offered).
2. A per-user document or row store (Supabase, Firebase or similar) with security rules.
3. Merge logic: current sync is whole-state last-write-wins, which can drop edits made on two devices. Per-record merge by `updatedAt` is recommended before launch.
4. Account deletion flow (required by both stores once accounts exist) and an updated privacy policy.
Until then the native app is local-only and its data is separate from the web version.
