# Build Android (APK for testing, AAB for Google Play)

Status: **project not generated or built here** (no Android SDK or registry access). Steps below were not executed in this environment.

## Prerequisites (any OS)
Node 20+ (22 used here), Android Studio (current stable), the JDK Capacitor requires (run `npx cap doctor`; Capacitor 7 documents JDK 21), a physical Android phone with USB debugging.
Plugin versions in `package.json` are `^7.0.0` and were **not verified against the registry**. If `npm install` complains, run `npx cap doctor` and align versions.

## 1. Generate the project
```
cd focusy-mobile
npm install
npm run sync-web
npm run add:android
npm run assets
npx cap sync android
```

## 2. One-time manual configuration
1. Open `native-config/android/AndroidManifest.additions.xml` and add those `uses-permission` lines to `android/app/src/main/AndroidManifest.xml`.
2. Copy `native-config/android/ic_stat_focusy.xml` to `android/app/src/main/res/drawable/`.
3. Signing: add this as the **last line** of `android/app/build.gradle`:
   `apply from: '../../native-config/android/signing.gradle'`
4. Versioning in `android/app/build.gradle` `defaultConfig`: `versionCode 1` (integer; increase for every upload) and `versionName "1.0.0"`.
5. Confirm `applicationId` is your final package id (`com.focusy.app` is a **placeholder**: choose it once, it cannot change after publishing; edit `capacitor.config.json` before `add:android`, or edit Gradle and the Java package afterwards).
6. Target SDK: Play requires a recent target API level; check the current requirement in Play Console before release.

## 3. Test on a device
Plug in the phone, `npm run open:android`, press Run. Then work through `docs/QA_CHECKLIST.md` (device column).

## 4. Create a signing key (once; back it up safely, never commit it)
```
keytool -genkeypair -v -keystore keys/focusy-upload.jks -alias focusy-upload -keyalg RSA -keysize 2048 -validity 10000
cp native-config/android/keystore.properties.example android/keystore.properties   # then fill in passwords
```
Enroll in **Play App Signing** (default for new apps): this key is only the *upload* key, so a lost key can be reset.

## 5. Build the release bundle
```
cd android
./gradlew bundleRelease
```
Output: `android/app/build/outputs/bundle/release/app-release.aab`. Upload it to a Play Console internal test track first.
For a quick installable test file: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`.

## Android-specific things to verify on device
- Alerts arrive on time with the screen locked and the app swiped away (Doze, battery saver, manufacturer task killers).
- "Enable notifications" asks for the Android 13+ permission and, if needed, opens the exact-alarm settings page.
- Edge-to-edge: the top bar and bottom nav are not hidden behind system bars on Android 15+.
