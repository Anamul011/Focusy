# Build iOS (TestFlight and App Store)

Status: **project not generated or built here.** iOS builds require macOS with Xcode; this environment is Linux. Steps were not executed.

## Prerequisites
A Mac with the current Xcode, Node 20+, the dependency manager your Capacitor version uses (`npx cap doctor` says which), an Apple Developer Program membership, a physical iPhone.

## 1. Generate the project
```
cd focusy-mobile
npm install
npm run sync-web
npm run add:ios
npm run assets
npx cap sync ios
npm run open:ios
```

## 2. Configure in Xcode
1. Target **App** > Signing & Capabilities: choose your Team, set the Bundle Identifier (`com.focusy.app` is a **placeholder**; it cannot be changed after the first App Store Connect upload).
2. General: Display Name `Focusy`, Version `1.0.0`, Build `1` (increase Build for every upload). Deployment target: the Capacitor default is fine.
3. Orientation: iPhone Portrait only is recommended (see `native-config/ios/Info.plist.additions.txt`).
4. Do not add Background Modes. Do not add usage-description strings: nothing else is requested.
5. Confirm a privacy manifest (`PrivacyInfo.xcprivacy`) is present in the App target and declares UserDefaults use (Preferences plugin) with an approved reason. The Capacitor template includes one; verify rather than assume.

## 3. Test on a device
Select your iPhone, Run, then work through `docs/QA_CHECKLIST.md`.

## 4. Release build
Product > Destination > Any iOS Device > Product > Archive > Distribute App > App Store Connect > Upload. Test through **TestFlight** before submitting for review.

## iOS-specific things to verify on device
- Alerts arrive with the phone locked; behaviour with Focus / Do Not Disturb (notifications are standard priority, not Time Sensitive).
- Top notch/Dynamic Island and home-indicator areas: nothing is cut off in the timer, Journey scene and tab bar.
- Keyboard does not cover the New Task and Task Detail fields.
- App Review guideline 4.2 (minimum functionality): Focusy has native alerts, offline data and device integration, which supports the case, but review is Apple's call.
