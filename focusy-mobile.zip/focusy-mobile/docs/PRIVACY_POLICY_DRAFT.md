# Focusy Privacy Policy (DRAFT, have this reviewed before publishing)

Last updated: [date]

Focusy is a personal productivity app. This policy describes the current version.

**What we collect.** Nothing. Focusy does not collect, transmit or share personal data. We have no accounts, analytics, advertising or tracking.

**What stays on your device.** The tasks, deadlines, focus sessions, planner data and settings you enter are stored locally on your device. Deleting the app deletes this data. Device backups made by your operating system may include it according to your device settings.

**Notifications.** If you allow them, Focusy schedules local notifications on your device (session complete, movement reminders, break over). They are created and delivered by your device; no information is sent to us.

**Permissions.** Notifications; keeping the screen on during an active focus session; on Android, permission to schedule exact-time alerts.

**Children.** Focusy is not directed at children under 13 and collects no data from anyone.

**Changes.** If we add features that involve online accounts or sync, we will update this policy and the app's store privacy information before release.

**Contact.** [your email address]
