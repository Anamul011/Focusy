# QA checklist and actual results

Legend: **PASS (auto)** = automated test, run in desktop Chromium at phone size, with a *simulated* Capacitor. **NOT TESTED** = needs a real device or a native build. Nothing below was run on a physical Android phone or iPhone.

Results recorded 2026-11-18. Commands: `npm run test:unit`, `python3 tests/e2e-native-bridge.py`, plus the shared suites in `../tests/`.

| # | Workflow | Web logic (auto) | Android device | iPhone device |
|---|---|---|---|---|
| 1 | Create / edit task, deadlines, planner | PASS (smart-planner 31/31, task-detail e2e) | NOT TESTED | NOT TESTED |
| 2 | Start / pause / resume / stop focus | PASS (focus-timer e2e, journey-app e2e 35/35) | NOT TESTED | NOT TESTED |
| 3 | Background and reopen; locked phone | Simulated only: clock shifted, state rebuilt from timestamps PASS. Real suspend/resume NOT TESTED | NOT TESTED | NOT TESTED |
| 4 | Complete a session, log once, summit summary | PASS | NOT TESTED | NOT TESTED |
| 5 | Movement reminders and breaks | PASS (movement-engine 18/18, flow e2e) | NOT TESTED | NOT TESTED |
| 6 | OS alerts (session end, move, break end) scheduled, replaced, cancelled | PASS against fake plugin (notePlan 14/14; bridge e2e 28/28). **Real delivery NOT TESTED** | NOT TESTED | NOT TESTED |
| 7 | Alert delivery with screen locked / app killed / Doze | NOT TESTED | NOT TESTED | NOT TESTED |
| 8 | Offline use | PASS (app makes no network calls; offline persistence in focus-timer e2e) | NOT TESTED | NOT TESTED |
| 9 | Data persistence and backup restore | PASS: localStorage wiped -> restored from fake Preferences; blank first save never overwrites backup | NOT TESTED | NOT TESTED |
| 10 | Five main tabs navigation | PASS (flow e2e) | NOT TESTED | NOT TESTED |
| 11 | Mountain journey follows real focus time | PASS (journey engine 18/18; e2e: pause freezes, lock jump, adjust eases) | NOT TESTED | NOT TESTED |
| 12 | Journey frame rate, battery, memory | NOT MEASURED | NOT TESTED | NOT TESTED |
| 13 | Reduced motion / disable animation | PASS in Chromium (`prefers-reduced-motion`, settings switches). WebView mapping from OS setting NOT TESTED | NOT TESTED | NOT TESTED |
| 14 | Safe areas (notch, status bar, home bar) | CSS in place; PASS for no overflow at 320/390/1280. Real insets NOT TESTED | NOT TESTED | NOT TESTED |
| 15 | Keyboard does not cover inputs | Scroll-into-view handler written; NOT TESTED | NOT TESTED | NOT TESTED |
| 16 | Android back button | PASS against fake App plugin | NOT TESTED | n/a |
| 17 | Keep screen awake during session | PASS against fake plugin (on while running, off when paused/stopped) | NOT TESTED | NOT TESTED |
| 18 | Status bar colour/style per theme | Called correctly against fake plugin | NOT TESTED | NOT TESTED |
| 19 | Icon, splash | Source art created and viewed; generated sizes NOT TESTED | NOT TESTED | NOT TESTED |
| 20 | Release build (AAB / IPA) | NOT BUILT | NOT BUILT | NOT BUILT |

## Automated counts (this session)
- Planner 31/31, movement 18/18, Journey engine 18/18 (preview and app), native alert planner 14/14.
- E2E: Journey in app 35/35; bridge 28/28 (three clean runs); focus-timer, flow and task-detail suites show no failures with the Journey off and the Journey-specific checks run in the Journey suite.
