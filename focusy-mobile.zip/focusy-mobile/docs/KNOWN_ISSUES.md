# Remaining technical issues and risks

**Blocking before any store submission**
1. Native projects are not generated and no build has been produced. Needs a machine with Android Studio (and a Mac for iOS).
2. No device testing at all. Items marked NOT TESTED in `QA_CHECKLIST.md` may reveal problems.
3. Package id `com.focusy.app` is a placeholder; confirm and register it.
4. Capacitor plugin versions in `package.json` were not checked against the registry.

**Functional gaps**
5. No cloud sync or accounts in the mobile apps (see `ARCHITECTURE.md`). Native data is separate from the web version until a backend is built. Existing sync is whole-state last-write-wins.
6. Background completion sound uses the system notification sound; the four-note chime plays only while the app is open. A custom sound file needs native assets per platform.
7. Android 14+: exact alerts need the user to grant the exact-alarm setting (the Enable notifications button opens it if needed). Without it, alerts can be late. Manufacturer battery optimisers can also delay or drop them.
8. iOS: alerts are standard priority, so Focus modes can silence them. Time Sensitive delivery would need an entitlement and Apple approval.
9. When an alert fires while the app is open the bridge deletes the duplicate banner; a brief flash on Android is possible.
10. The existing late-evening planner message ("Nothing needed today" in the 6-9 PM window) is unchanged.

**Performance (unmeasured)**
11. The Journey draws a full canvas scene each frame while running. Desktop headless runs are fine; mid-range phones are untested. Levers if needed: cap DPR at 1.5, 30 fps cap, or reduce ridge layers.
12. Battery impact of a long session with the screen kept awake is unmeasured.

**Things that are fine by design**
- Timers use timestamps, not ticks, so any pause in the WebView cannot make progress drift.
- Only 3 notifications are ever pending (iOS limit is 64).
