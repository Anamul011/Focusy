# Focusy Mobile (Android + iOS)

One Focusy product, three platforms. The mobile apps are a **Capacitor** shell around the same single-file web app (`../unified-focus.html`). Nothing was rebuilt; every feature (Today, One Thing, Focus Timer, Mountain Journey, Deadlines, Matrix, movement breaks, sounds, settings) is the shared code.

## What is in this folder
| Path | Purpose |
|---|---|
| `web/index.html` | The Focusy app (copied from `../unified-focus.html` by `npm run sync-web`) |
| `web/native.js` | Native bridge. Inert in a browser. Adds OS alerts, storage backup, keep-awake, status bar, splash, keyboard, Android back button |
| `capacitor.config.json` | App id `com.focusy.app` (placeholder, see docs), name, splash, keyboard, notification settings |
| `package.json` | Capacitor dependencies and scripts |
| `assets/` | Icon and splash sources (generate all sizes with `npm run assets`) |
| `native-config/` | Files to apply to the generated `android/` and `ios/` projects (signing, manifest, notification icon) |
| `tests/` | Unit and end-to-end tests for the native layer |
| `docs/` | Architecture, build, store readiness, QA record, known issues, privacy policy draft |

## Status in one paragraph
The shared code and native layer are **written and tested against a simulated Capacitor**. The `android/` and `ios/` native projects are **not generated yet**: this environment has no Android SDK, no Xcode (iOS needs a Mac) and no package registry access. Generating them is three commands (see `docs/BUILD_ANDROID.md`, `docs/BUILD_IOS.md`). **Nothing has been run on a physical phone.** See `docs/QA_CHECKLIST.md` for exactly what was and was not tested.

## Quick start
```
cd focusy-mobile
npm install
npm run sync-web
npm run add:android        # any OS
npm run add:ios            # Mac only
npm run assets             # icons + splash for both
npx cap sync
npm run open:android       # or open:ios
```
Then follow the one-time manual steps in the build docs (manifest permissions, notification icon, signing).

## Keeping web and mobile in sync
Edit the web app as usual, then run `npm run sync` in this folder. The sync script refuses to run if the source is missing the native hooks.
