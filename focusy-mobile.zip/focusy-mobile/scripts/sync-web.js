// Copies the shared Focusy web app into the native shell and wires in native.js (idempotent).
const fs=require('fs'),path=require('path');
const src=path.resolve(process.argv[2]||'../unified-focus.html'),dst=path.join(__dirname,'..','web','index.html');
if(!fs.existsSync(src)){console.error('Source not found:',src);process.exit(1)}
let h=fs.readFileSync(src,'utf8');
for(const need of['FocusyNative.onSave','notePlan','viewport-fit=cover']){if(!h.includes(need)){console.error('Source is missing required marker:',need);process.exit(1)}}
if(!h.includes('src="native.js"'))h=h.replace('</head>','<script src="native.js"></script>\n</head>');
if(!h.includes('src="native.js"')){console.error('Could not inject native.js (no </head>)');process.exit(1)}
fs.writeFileSync(dst,h);console.log('web/index.html updated from',src,'('+h.length+' bytes)');
