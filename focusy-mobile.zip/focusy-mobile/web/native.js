/* Focusy native bridge. Loaded before the app. Does nothing in a normal browser.
   Inside the Capacitor shell it adds: OS-scheduled alerts (timers stop in the background), storage mirroring,
   keep-awake, status bar/splash/keyboard polish and the Android back button. No bundler needed: plugins are
   reached through window.Capacitor.Plugins. */
(function(){
 var C=window.Capacitor,native=!!(C&&C.isNativePlatform&&C.isNativePlatform()),N={native:native,platform:native?C.getPlatform():'web',perm:'unknown',log:[]};
 window.FocusyNative=N;
 var noop=function(){};N.onSave=noop;N.awake=noop;N.ask=function(){return Promise.resolve()};
 if(!native)return;
 var P=C.Plugins||{},LN=P.LocalNotifications,Pref=P.Preferences,KA=P.KeepAwake,SB=P.StatusBar,SS=P.SplashScreen,KB=P.Keyboard,App=P.App,KEY='uf1',IDS=[9001,9002,9003];
 function err(w,e){try{N.log.push(w+': '+(e&&e.message||e));if(N.log.length>30)N.log.shift()}catch(x){}}
 function sp(w,f){try{var r=f();return r&&r.catch?r.catch(function(e){err(w,e)}):Promise.resolve(r)}catch(e){err(w,e);return Promise.resolve()}}
 /* 1. Storage mirror: WebView storage can be cleared by the OS under pressure; Preferences (UserDefaults / SharedPreferences) is the safety copy. */
 var mt=0,pending=null,restoring=false;
 function flush(){clearTimeout(mt);if(restoring||pending==null||!Pref)return;var v=pending;pending=null;sp('mirror',function(){return Pref.set({key:KEY,value:v})})}
 try{var _set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){_set.apply(this,arguments);if(this===window.localStorage&&k===KEY&&!restoring){pending=String(v);clearTimeout(mt);mt=setTimeout(flush,400)}}}catch(e){err('patch',e)}
 /* While the restore check is pending the app may write a blank default state; never mirror that over the real backup. */
 if(Pref){try{if(!localStorage.getItem(KEY)&&!sessionStorage.getItem('fy_restored')){restoring=true;
  Pref.get({key:KEY}).then(function(r){if(r&&r.value){sessionStorage.setItem('fy_restored','1');localStorage.setItem(KEY,r.value);location.reload()}else{restoring=false;var cur=localStorage.getItem(KEY);if(cur){pending=cur;flush()}}}).catch(function(e){restoring=false;err('restore',e)})}
  else if(localStorage.getItem(KEY)&&Pref)Pref.get({key:KEY}).then(function(r){if(!r||!r.value)Pref.set({key:KEY,value:localStorage.getItem(KEY)})}).catch(noop)}catch(e){err('restore',e)}}
 /* 2. OS-scheduled alerts. The app passes the full list for the current session on every save; ids are fixed so each call replaces the last. */
 var chain=Promise.resolve(),lastSig='[]',asked=false;
 function ensurePerm(){if(!LN)return Promise.resolve(false);if(N.perm==='granted')return Promise.resolve(true);
  return sp('perm',function(){return LN.checkPermissions().then(function(r){N.perm=r.display;if(r.display==='granted')return true;if(asked||r.display==='denied')return false;asked=true;return LN.requestPermissions().then(function(q){N.perm=q.display;return q.display==='granted'})})}).then(function(v){return !!v})}
 function apply(plan){return ensurePerm().then(function(ok){
  return sp('cancel',function(){return LN.cancel({notifications:IDS.map(function(i){return{id:i}})})}).then(function(){
   if(!ok||!plan.length)return;
   return sp('schedule',function(){return LN.schedule({notifications:plan.map(function(n){return{id:n.id,title:n.title,body:n.body,channelId:'focus',schedule:{at:new Date(n.at),allowWhileIdle:true}}})})})})})}
 N.onSave=function(plan){plan=plan||[];var sig=JSON.stringify(plan.map(function(n){return[n.id,Math.round(n.at/1000)]}));if(sig===lastSig)return;lastSig=sig;chain=chain.then(function(){return apply(plan)})};
 /* Android 12+: exact-time alerts need a user-granted setting, otherwise the OS may delay them by minutes. Opens the system page only when needed. */
 N.ask=function(){asked=false;N.perm='unknown';return ensurePerm().then(function(){
  if(N.platform!=='android'||!LN||!LN.checkExactNotificationSetting)return;
  return sp('exact',function(){return LN.checkExactNotificationSetting().then(function(r){if(r&&r.exact_alarm==='denied'&&LN.changeExactNotificationSetting)return LN.changeExactNotificationSetting()})})})};
 if(LN){sp('channel',function(){return LN.createChannel({id:'focus',name:'Focus sessions',description:'Session end, movement and break reminders',importance:4,visibility:1,vibration:true})});
  sp('perm0',function(){return LN.checkPermissions().then(function(r){N.perm=r.display})});
  /* If an alert fires while the app is open the app already shows it itself, so clear the duplicate. */
  sp('recv',function(){return LN.addListener('localNotificationReceived',function(){if(!document.hidden)sp('rm',function(){return LN.removeAllDeliveredNotifications()})})})}
 /* 3. Keep the screen on only while a session is running. */
 N.awake=function(on){if(!KA)return;sp('awake',function(){return on?KA.keepAwake():KA.allowSleep()})};
 /* 4. Lifecycle: flush storage when leaving; re-run the app's own resume logic when returning. */
 if(App){sp('state',function(){return App.addListener('appStateChange',function(s){if(!s.isActive)flush();else setTimeout(function(){if(!document.hidden)document.dispatchEvent(new Event('visibilitychange'))},50)})});
  sp('back',function(){return App.addListener('backButton',function(){
   var t=document.getElementById('timer'),m=document.getElementById('modal');
   if(t&&t.style.display!=='none'&&t.innerHTML){var b=t.querySelector('[data-act="tmin"]')||t.querySelector('[data-act="tclose"]');if(b){b.click();return}}
   if(m&&m.innerHTML){var c=m.querySelector('[data-act="close"]');if(c){c.click();return}}
   if(App.minimizeApp)App.minimizeApp();else if(App.exitApp)App.exitApp()})})}
 document.addEventListener('visibilitychange',function(){if(document.hidden)flush()});
 /* 5. Status bar follows the app theme; splash hides when the page is ready. */
 function theme(){var a=document.documentElement.getAttribute('data-theme'),dark=a?a==='dark':matchMedia('(prefers-color-scheme: dark)').matches;
  if(SB){sp('sbs',function(){return SB.setStyle({style:dark?'DARK':'LIGHT'})});if(N.platform==='android')sp('sbc',function(){return SB.setBackgroundColor({color:dark?'#0b0820':'#f6f6fb'})})}}
 document.addEventListener('DOMContentLoaded',function(){theme();try{new MutationObserver(theme).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']})}catch(e){}
  if(SS)setTimeout(function(){sp('splash',function(){return SS.hide()})},150)});
 /* 6. Keep the focused field visible above the keyboard. */
 if(KB)sp('kb',function(){return KB.addListener('keyboardDidShow',function(){var a=document.activeElement;if(a&&/INPUT|TEXTAREA|SELECT/.test(a.tagName))setTimeout(function(){try{a.scrollIntoView({block:'center',behavior:'smooth'})}catch(e){}},120)})});
})();
